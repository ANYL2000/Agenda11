<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="shortcut icon" href="assets/img/icono_membretado.png" type="image/x-icon" >
    <title>SERVICIOS GENERALES</title>
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.0/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <!-- Custom CSS -->
    <link href="assets/css/styles.css" rel="stylesheet">	
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css"
    />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
   
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-tagsinput/0.8.0/bootstrap-tagsinput.css"
      rel="stylesheet"
    />
	<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-down" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
</svg>
    <!-- DateTimePicker CSS -->
	<link href="assets/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">	
	<!-- DataTables CSS -->
    <link href="assets/css/dataTables.bootstrap.css" rel="stylesheet">	
	<!-- FullCalendar CSS -->
	<link href="assets/css/fullcalendar.css" rel="stylesheet" />
	<link href="assets/css/fullcalendar.print.css" rel="stylesheet" media="print" />	
 <!-- jQuery -->
 <script src="assets/js/jquery.js"></script>	
    <!-- DateTimePicker CSS -->
	<link href="assets/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">
  <script src="assets/js/isotope.pkgd.min.js"></script> 
 
    
  </head>
  <style type="text/css">
    .bootstrap-tagsinput .tag {
      margin-right: 2px;
      color: white !important;
      background-color: #0d6efd;
      padding: 0.2rem;
    }
  </style>
  <body>

  <nav class="navbar navbar-expand-lg fixed-top navbar-dark bg-dark ">
	
  <!--<div class="row">
<div class="col-md-8">
<img class="rounded float-start img-responsive" src="assets/img/cualtos_blanco.png" alt="">
</div>
</div>-->

    <div class="container topnav">

    <a class="navbar-brand" href="#home">
    <h1><i class="" aria-hidden="true"></i> Servicios Generales</h1></a>
   
    <div class="collapse navbar-collapse justify-content-end" id="navbarNavAltMarkup">
      <div class="navbar-nav">
      <!--<a class="nav-link active" aria-current="page" href="#home">Solicitud</a>
      <a class="nav-link" href="#eventcalendar">Agenda</a>
      <a class="nav-link" href="#ticket_events">Tickets</a>-->
      </div>
    </div>
    </div>
  </nav>

  <!-- Header -->
   <div id="home"></div>
  <div class="intro-header img-responsive">
    <div class="container">

      <div class="row">
        <div class="col-lg-7">
          <div class="intro-message">
            <h1><i class="" aria-hidden="true"></i> Servicios Generales</h1>
            <h3>Solicitud de préstamos</h3>
            <hr class="intro-divider">
            <div class="form-group">
            <!-- Button trigger New Event modal -->
							<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#event">
							 <i class="fa-solid fa-rectangle-history-circle-plus" ></i> Solicitar préstamo
							</button> 
          </div>                       
          </div>
        </div>
      </div>

    </div>
    <!-- /.container -->
  </div>

  <!-- New Event Creation Modal -->
  <div class="modal fade" id="event" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
								<div class="modal-dialog modal-lg modal-dialog-scrollable" role="document">
									<div class="modal-content">
										<div class='modal-header'>
											<h5 class='modal-title'><i class='fa-regular fa-rectangle-history-circle-plus' aria-hidden='true'></i> Solicitar préstamo</h5>
											<button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
										</div>
										<div class="modal-body">
											 <!-- New Event Creation Form -->
											<form action="" method="post" enctype="multipart/form-data" class="form-horizontal" name="novoevento">
												<fieldset>
													<!-- CSRF PROTECTION -->
													<input type="hidden" name="_csrf" value="de2c2fea4464a643855cc8be9b0cf117" />	
													
													<div class="form-group" >
												  <div class="text-center" style="font-size:22px;  background: rgb(9, 9, 80);color:white;">Datos del solicitante</div>
												  </div>
												  <br>
													
													<!-- Text input-->
													<div class="form-group">
														<label class="col-md-3 control-label" for="title">Área de adscripción*</label>
														<div class="col-md-4">
															<select name='title' class="form-control form-select input-md" required>
																
																<option value='' >Seleccionar</option>
																	
																	<option value='Patrimonio'>Patrimonio</option>
																	

																																</select>
														</div>
													</div>
													
													<!-- Text input
													<div class="form-group">
														<label class="col-md-3 control-label" for="color">Color</label>
														<div class="col-md-4">
															<div id="cp1" class="input-group colorpicker-component">
																<input id="cp1" type="text" class="form-control form-control-color" name="color" value="#5367ce" required/>
																<span class="input-group-addon"><i></i></span>
															</div>
														</div>
													</div>-->

														
													<div class="form-group">
            									<label for="recipient-name" class="col-form-label">Nombre completo del solicitante*</label>
          
           										 <input type="text" class="form-control" id="nombre_solicitante" name="nombre_solicitante"  required autocomplete="off">
         										 </div>

												  <div class="row">
												  <div class="form-group col-md-6">
            									<label for="recipient-name" class="col-form-label">Correo Electrónico*</label>
          
           										 <input type="text" class="form-control" id="correo_solicitante" name="correo_solicitante"  required autocomplete="off">
         										 </div>


												  <div class="form-group col-md-6">
            									<label for="recipient-name" class="col-form-label">Telefono de contacto*</label>
          
           										 <input type="text" class="form-control" id="correo_solicitante" name="correo_solicitante"  required autocomplete="off">
         										 </div>
												  </div>

												 <br>
												  <div class="form-group" >
												  <div class="text-center" style="font-size:22px;  background: rgb(9, 9, 80);color:white;">Apoyos solicitados (marcar el servicio que necesita)</div>
												  </div>
												  

												  <div class="form-group" >
												  <div class="text-center" style="font-size:15px;  background: rgb(9, 9, 80);color:white;">Características de los vehiculos a utilizar</div>
												  </div>
												  <br>
		
	<div class="form-group row">
    
    
      <div class="col-sm-10">
	  <div class="form-check">
        <input class="form-check-input" type="radio" name="vehiculo" onclick="ocultar_nombre_chofer()" id="gridCheck1" value="Vehículo Personal" required>
        <label class="form-check-label" for="gridCheck1">
          Vehículo Personal
        </label>
		</div>
      </div>

	  <div class="col-sm-10">
	  <div class="form-check">
        <input class="form-check-input" type="radio" name="vehiculo" onclick="mostrar_nombre_chofer()"id="gridCheck1" value="Vehículo Oficial con chofer" required>
        <label class="form-check-label" for="gridCheck1">
          Vehículo Oficial con chofer
        </label>
		</div>
      </div>
      
	  <div class="form-group col-md-10" id="chofer_nombre" hidden="true">
        <label for="recipient-name" class="col-form-label">Nombre del chofer del vehículo oficial:</label>
         <input type="text" class="form-control" id="nombre_chofer" name="nombre_chofer"  autocomplete="off">
		<br>
		</div>

		<script>
			function mostrar_nombre_chofer(){
				var cambio1 = document.getElementById("chofer_nombre");
   				var nombre_chofer = document.getElementById("nombre_chofer");
				if(cambio1.hidden == true){
					nombre_chofer.required = true;
					cambio1.hidden = false;
				}
				 
				 
			}
			function ocultar_nombre_chofer(){


				var cambio1 = document.getElementById("chofer_nombre");
				var nombre_chofer = document.getElementById("nombre_chofer");
				   if(cambio1.hidden == false){
					nombre_chofer.required = false;
					   cambio1.hidden = true;
				   }
			}
		</script>


	  <div class="col-sm-10">
      <div class="form-check">
        <input class="form-check-input" type="radio" name="vehiculo" onclick="ocultar_nombre_chofer()" id="gridCheck1" value="Vehículo Oficial sin chofer" required>
        <label class="form-check-label" for="gridCheck1">
          Vehículo Oficial sin chofer
        </label>
      </div>
	  <br>
    </div>
	
	     
		<div class="form-group" >
	 <div class="text-center" style="font-size:15px;  background: rgb(9, 9, 80);color:white;">Gastos del viaje</div>
  
	</div>

	<div class="col-sm-10" >
		<br>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" id="gridCheck1" name="peajes" value="Peajes" >
        <label class="form-check-label" for="gridCheck1">
          Peajes
        </label>
      </div>
    </div>

	<div class="col-sm-10">
      <div class="form-check">
        <input class="form-check-input" type="checkbox" id="gridCheck1" name="gasolina" value="Gasolina" >
        <label class="form-check-label" for="gridCheck1">
          Gasolina (solo en caso de utilizar vehículo personal)
        </label>
      </div>
    </div>

	<div class="col-sm-10">
      <div class="form-check">
        <input class="form-check-input" type="checkbox" id="gridCheck1" name="pago_compartido" value="Renta de vehículo con pago compartido" >
        <label class="form-check-label" for="gridCheck1">
          Renta de vehículo con pago compartido (%)
        </label>
      </div>
    </div>
	

  </div>
         										 
											
													<br>
													<div class="form-group" >
												  <div class="text-center" style="font-size:22px;  background: rgb(9, 9, 80);color:white;">Fechas del préstamo</div>
												  </div>
												
													<br>
  											<div class="form-group">
											  <button type="button" class="btn btn-primary habilitar_dias" id="habilitar_dias" name="habilitar_dias" onclick="mostrar_contenedor_dias()"><i class="bi bi-chevron-down habilitar_dias_icono"></i> Repetir por dia</button>

											</div>
													<br>
													<!--flexSwitchCheckDefault-->
													<div class="shadow-lg p-3 mb-5 bg-white rounded" id="contenedor_dias" hidden="true">
													<div class="row">
													<div class="form-group col-md-3">
														<div class="form-check form-switch">
  													<input class="form-check-input dias_semana" type="checkbox" id="lunes" name="lunes" value="1">
 													 <label class="form-check-label" for="lunes">Lunes</label>
														</div>
														<div class="form-check form-switch">
  													<input class="form-check-input dias_semana" type="checkbox" id="martes" name="martes" value="2">
 													 <label class="form-check-label" for="martes">Martes</label>
														</div>
														<div class="form-check form-switch">
  													<input class="form-check-input dias_semana" type="checkbox" id="miercoles" name="miercoles" value="3">
 													 <label class="form-check-label" for="miercoles">Miercoles</label>
														</div>
														<div class="form-check form-switch">
  													<input class="form-check-input dias_semana" type="checkbox" id="jueves" name="jueves" value="4">
 													 <label class="form-check-label" for="jueves">Jueves</label>
														</div>
														<div class="form-check form-switch">
  													<input class="form-check-input dias_semana" type="checkbox" id="viernes" name="viernes" value="5">
 													 <label class="form-check-label" for="viernes">Viernes</label>
														</div>
														<div class="form-check form-switch">
  													<input class="form-check-input dias_semana" type="checkbox" id="sabado" name="sabado" value="6">
 													 <label class="form-check-label" for="sabado">Sabado</label>
														</div>
														<div class="form-check form-switch">
  													<input class="form-check-input dias_semana" type="checkbox" id="domingo" name="domingo" value="7">
 													 <label class="form-check-label" for="domingo">Domingo</label>
														</div> 
														</div>

														<div class="form-group col-md-8">
																<div class="row">
														<div class="form-group col-md-6">
            									<label for="recipient-name" class="col-form-label">Fecha inicio (desde)</label>
          
           										 <input type="date" class="form-control" id="fecha_inicio" name="fecha_inicio" autocomplete="off">
         										 		</div>

														  <div class="form-group col-md-6">
            									<label for="recipient-name" class="col-form-label">Fecha final (hasta)</label>
          
           										 <input type="date" class="form-control" id="fecha_final" name="fecha_final"  autocomplete="off">
         										 		</div>

														  </div>

														  <div class="form-group col-md-7">
																<div class="row">
														<div class="form-group col-md-6">
            									<label for="recipient-name" class="col-form-label">Hora inicio (desde)</label>
          
           										 <input type="time" class="form-control" id="hora_inicio" name="hora_inicio"  autocomplete="off">
         										 		</div>

														  <div class="form-group col-md-6">
            									<label for="recipient-name" class="col-form-label">Hora final (hasta)</label>
          
           										 <input type="time" class="form-control" id="hora_final" name="hora_final"  autocomplete="off">
         										 		</div>

														  </div>
            										</div>

            										</div>

												  		</div>
														</div>

														<script>
			function mostrar_contenedor_dias(){
				var cambio1 = document.getElementById("contenedor_dias");
				//var dias = document.getElementsByClassName("dias_semana");
				var fecha_inicio = document.getElementById("fecha_inicio");
				var fecha_final = document.getElementById("fecha_final");
				var hora_inicio = document.getElementById("hora_inicio");
				var hora_final = document.getElementById("hora_final");
				var lunes = document.getElementById("lunes");
				var martes = document.getElementById("martes");
				var miercoles = document.getElementById("miercoles");
				var jueves = document.getElementById("jueves");
				var viernes = document.getElementById("viernes");
				var sabado = document.getElementById("sabado");
				var domingo = document.getElementById("domingo");
				var cambio2 = document.getElementById("fechas_salida_regreso");
   				var start = document.getElementById("start");
				   var end = document.getElementById("end");
				   var todo_el_dia = document.getElementById('todo_el_dia');
				   var campos_todo_dia = document.getElementById('campos_todo_dia');
				   var fecha_todo_dia = document.getElementById('fecha_todo_dia');
				   var todo_dia_input = document.getElementById('fecha_todo_dia_input');
				if(cambio1.hidden == true){
					todo_el_dia.checked = false;
					campos_todo_dia.hidden = true;
					todo_dia_input.required = false;
					fecha_todo_dia.hidden = true;
					lunes.checked = false;
					martes.checked = false;
					miercoles.checked = false;
					jueves.checked = false;
					viernes.checked = false;
					sabado.checked = false;
					domingo.checked = false;
					fecha_inicio.required = true;
					fecha_final.required = true;
					hora_inicio.required = true;
					hora_final.required = true;
					//dias.required = true;
					cambio1.hidden = false;
					start.required = false;
					end.required = false;
					start.value = "";
					end.value = "";
					cambio2.hidden = true;
					$('#habilitar_dias').removeClass('btn-primary');
                $('#habilitar_dias').addClass('btn-dark');
				$('.habilitar_dias_icono').removeClass('bi bi-chevron-down').addClass('bi bi-chevron-up');
				}else{
					todo_el_dia.checked = false;
					campos_todo_dia.hidden = false;
					fecha_todo_dia.hidden = true;
					todo_dia_input.required = false;
					lunes.checked = false;
					martes.checked = false;
					miercoles.checked = false;
					jueves.checked = false;
					viernes.checked = false;
					sabado.checked = false;
					domingo.checked = false;
					//dias.required = false;
					fecha_inicio.required = false;
					fecha_final.required = false;
					hora_inicio.required = false;
					hora_final.required = false;
					cambio1.hidden = true;
					start.required = true;
					start.value = "";
					end.value = "";
					end.required = true;
					cambio2.hidden = false;
					$('#habilitar_dias').removeClass('btn-dark');
                $('#habilitar_dias').addClass('btn-primary');
				$('.habilitar_dias_icono').removeClass('bi bi-chevron-up').addClass('bi bi-chevron-down');
				}
				 
				 
			}
		
	
		</script>


														<br>
												 <div class="row" id="fechas_salida_regreso">
													<div class="form-group col-md-6">
														<label class="col-md-6 control-label" for="start">Fecha de salida</label>
														<div class="input-group date form_date col-md-6" data-date="" data-date-format="yyyy-mm-dd hh:ii" data-link-field="start" data-link-format="yyyy-mm-dd hh:ii">
															<span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span><input class="form-control" size="16" type="text" id="inicio" value="" readonly >
														</div>
														<input id="start" name="start" type="hidden" value="" required>

													</div>

													<div class="form-group col-md-6">
														<label class="col-md-8 control-label" for="end">Fecha de regreso</label>
														<div class="input-group date form_date col-md-6" data-date="" data-date-format="yyyy-mm-dd hh:ii" data-link-field="end" data-link-format="yyyy-mm-dd hh:ii">
															<span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span><input class="form-control" size="16" type="text" id="fin" value="" readonly >
														</div>
														<input id="end" name="end" type="hidden" value="" required>

													</div>
														
													</div>
															<br>
														<div class="row" id="campos_todo_dia">
															
													<div class="col-md-4">
													
      												<div class="form-check">
      												  <input class="form-check-input" type="checkbox" id="todo_el_dia" onclick="mostrar_fecha_todo_dia()" value="true">
      											  <label class="form-check-label" for="todo_el_dia">
      												    Todo el dia
      												  </label>
      													</div>
   														 </div>
																	
															<div class="form-group col-md-6" id="fecha_todo_dia" hidden="true">
            									<label for="recipient-name" class="col-form-label">Fecha para todo el dia</label>
          
           										 <input type="date" class="form-control" id="fecha_todo_dia_input" name="fecha_todo_dia_input"  required autocomplete="off">
         										 		</div>


															</div>

				<script>

					function mostrar_fecha_todo_dia(){
							var fecha_todo_dia = document.getElementById('fecha_todo_dia');
							var todo_el_dia = document.getElementById('todo_el_dia');
							var todo_dia_input = document.getElementById('fecha_todo_dia_input');
							var cambio2 = document.getElementById("fechas_salida_regreso");
							var start = document.getElementById("inicio");
							var end = document.getElementById("fin");
							var dias = document.getElementsByClassName("dias_semana");
				var lunes = document.getElementById("lunes");
				var martes = document.getElementById("martes");
				var miercoles = document.getElementById("miercoles");
				var jueves = document.getElementById("jueves");
				var viernes = document.getElementById("viernes");
				var sabado = document.getElementById("sabado");
				var domingo = document.getElementById("domingo");
					if(fecha_todo_dia.hidden == true&&todo_el_dia.checked == true){
						lunes.checked = false;
					martes.checked = false;
					miercoles.checked = false;
					jueves.checked = false;
					viernes.checked = false;
					sabado.checked = false;
					domingo.checked = false;
					dias.required = false;
						todo_dia_input.required = true;
						todo_dia_input.value = "";
						start.value = "";
						end.value = "";
						todo_el_dia.required = true;
						fecha_todo_dia.hidden = false;
						cambio2.hidden = true;
					}else{
						lunes.checked = false;
					martes.checked = false;
					miercoles.checked = false;
					jueves.checked = false;
					viernes.checked = false;
					sabado.checked = false;
					domingo.checked = false;
					dias.required = false;
						todo_dia_input.required = false;
						todo_el_dia.required = false;
						todo_dia_input.value = "";
						start.value = "";
						end.value = "";
						fecha_todo_dia.hidden = true;
						cambio2.hidden = false;
					}
				}
				</script>
					
														<br>
													<div class="form-group" >
												  <div class="text-center" style="font-size:22px;  background: rgb(9, 9, 80);color:white;">Datos Adicionales</div>
												  </div>
												
													<br>
													<div class="row">
												  <div class="form-group col-md-5">
            									<label for="recipient-name" class="col-form-label">Núm. Personas que viajan:</label>
          
           										 <input type="number" class="form-control" id="total_personas" name="total_personas" min="1" autocomplete="off">
         										 </div>


												  <div class="form-group col-md-7">
            									<label for="recipient-name" class="col-form-label col-md-10">Nombre de persona/s:</label>
                             
                            					<input type="text" class="form-control" data-role="tagsinput" id="nombre_personas" name="nombre_personas"/>
                          
           										 <!--<input type="text" class="form-control" id="correo_solicitante" name="correo_solicitante"  required autocomplete="off">-->
         										 </div>

												  <div class="form-group col-md-6">
            									<label for="recipient-name" class="col-form-label">Descripción</label>
          
           										 <input type="textarea" class="form-control" id="descripcion" name="descripcion"  autocomplete="off">
         										 </div>

												  </div>

												  <br>
													<div class="form-group" >
												  <div class="text-center" style="font-size:22px;  background: rgb(9, 9, 80);color:white;">Destino</div>
												  </div>
												
													<br>
												  <div class="form-group col-md-10">
            									<label for="recipient-name" class="col-form-label">Domicilio:</label>
           										 <input type="text" class="form-control" id="domicilio" name="domicilio"  required autocomplete="off">
         										 </div>
												
												  <div class="form-group col-md-10">
												 
												</div>
									


			

													<!-- Text input
													<div class="form-group">
														<label class="col-md-3 contro-llabel" for="description">Descripción</label>
														<div class="col-md-12">
															<textarea class="form-control" rows="5" name="description" id="description"></textarea>
														</div>
													</div>
													
													Text input
													<div class="form-group">
														<label class="col-md-3 control-label" for="location">Location</label>
														<div class="col-md-12">
															<textarea class="form-control" rows="1" name="location" id="location"></textarea>
														</div>
													</div>-->


													<!-- Button -->
													<div class="form-group">
														<label class="col-md-12 control-label" for="singlebutton"></label>
														<div class="col-md-4">
															<input type="submit" name="novoevento" class="btn btn-success" value="Solicitar ahora" />
														</div>
													</div>

												</fieldset>
											</form>  
										</div>
										<div class="modal-footer">
											<button type='button' class='btn btn-primary' data-bs-dismiss='modal'>Cerrar</button>
										</div>
									</div>
								</div>
							</div>	


   
   
  </body>
  <!-- Bootstrap Core JavaScript -->
  <script src="assets/js/bootstrap.min.js"></script>
		<!-- DataTables JavaScript -->
		<script src="assets/js/jquery.dataTables.js"></script>
		<script src="assets/js/dataTables.bootstrap.js"></script>
		<!-- Listings JavaScript delete options-->
		<script src="assets/js/listings.js"></script>
		<!-- Metis Menu Plugin JavaScript -->
		<script src="assets/js/metisMenu.min.js"></script>
		<!-- Moment JavaScript -->
		<script src="assets/js/moment.min.js"></script>
		<!-- FullCalendar JavaScript -->
		<script src="assets/js/fullcalendar.js"></script>
		<!-- FullCalendar Language JavaScript Selector -->
		<script src='assets/lang/en-gb.js'></script>
		<!-- DateTimePicker JavaScript -->
		<script type="text/javascript" src="assets/js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
		<!-- Option 1: Bootstrap Bundle with Popper -->
        <script src="assets/js/bootstrap.bundle.min.js" ></script>  
		<!-- Datetime picker initialization -->
		<script type="text/javascript">	
			"use strict";
			$('.form_date').datetimepicker({
				language:  'en',
				weekStart: 1,
				todayBtn:  0,
				autoclose: 1,
				todayHighlight: 1,
				startView: 2,
				forceParse: 0
			});
		</script>	
		<!-- ColorPicker JavaScript -->
		<script src="assets/js/bootstrap-colorpicker.js"></script>
		<!-- Plugin Script Initialization for DataTables -->
		<script>
			"use strict";
			$(document).ready(function() {				
				$('.dataTables-example').dataTable();
			});
		</script>
		<!-- ColorPicker Initialization -->
		<script>
			"use strict";
			$(function() {
				"use strict";
				$('#cp1').colorpicker();
				$('#cp2').colorpicker();
			});
		
		</script>
		<!-- JS array created from database -->

  <script
    src="https://code.jquery.com/jquery-3.6.0.min.js"
    integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
    crossorigin="anonymous"
  ></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.0/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-tagsinput/0.8.0/bootstrap-tagsinput.min.js"></script>
  <script>
	

	$( "#total_personas" ).change(function() {
		var total = $("#total_personas").val();
       return total;
    });


    $(function () {
      $('input')
        .on('change', function (event) {


          var $element = $(event.target);
          var $container = $element.closest('.example');

          if (!$element.data('tagsinput')) return;
				
        var val = $element.val(); //se guardan los valores en una lista
		
		

          if (val === null) val = 'null';
          var items = $element.tagsinput('items');

          $('code', $('pre.val', $container)).html(
            $.isArray(val)
              ? JSON.stringify(val)
              : '"' + val.replace('"', '\\"') + '"'
          );
          $('code', $('pre.items', $container)).html(
            JSON.stringify($element.tagsinput('items'))
          );
        })
        .trigger('change');
    });
  </script>
</html>